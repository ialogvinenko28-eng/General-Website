document.addEventListener('DOMContentLoaded', () => {
	const clockEl = document.getElementById('nav-clock');
	const box = document.querySelector('.color-box');

	if (!clockEl) return;

	// Heritage button handler and modal behavior
	const heritageBtn = document.getElementById('heritage');
 	const heritageModal = document.getElementById('heritage-modal');
 	const heritageClose = document.getElementById('heritage-close');

	if (heritageBtn && heritageModal) {
		heritageBtn.addEventListener('click', (e) => {
			e.preventDefault();
			heritageModal.classList.add('active');
			heritageModal.setAttribute('aria-hidden', 'false');
			const dialog = heritageModal.querySelector('.heritage-dialog');
			if (dialog) dialog.focus();
		});

		// Close when clicking the close button or outside the dialog
		heritageModal.addEventListener('click', (e) => {
			if (e.target === heritageModal || e.target === heritageClose) {
				heritageModal.classList.remove('active');
				heritageModal.setAttribute('aria-hidden', 'true');
			}
		});

		// Close on Escape key
		document.addEventListener('keydown', (e) => {
			if (e.key === 'Escape') {
				heritageModal.classList.remove('active');
				heritageModal.setAttribute('aria-hidden', 'true');
			}
		});
	}

	// Relationship button handler and modal behavior
	const relationshipBtn = document.getElementById('relationship');
	const relationshipModal = document.getElementById('relationship-modal');
	const relationshipClose = document.getElementById('relationship-close');

	if (relationshipBtn && relationshipModal) {
		relationshipBtn.addEventListener('click', (e) => {
			e.preventDefault();
			relationshipModal.classList.add('active');
			relationshipModal.setAttribute('aria-hidden', 'false');
			const dialog = relationshipModal.querySelector('.relationship-dialog');
			if (dialog) dialog.focus();
		});

		relationshipModal.addEventListener('click', (e) => {
			if (e.target === relationshipModal || e.target === relationshipClose) {
				relationshipModal.classList.remove('active');
				relationshipModal.setAttribute('aria-hidden', 'true');
			}
		});

		document.addEventListener('keydown', (e) => {
			if (e.key === 'Escape') {
				relationshipModal.classList.remove('active');
				relationshipModal.setAttribute('aria-hidden', 'true');
			}
		});
	}

	function pad(n) { return String(n).padStart(2, '0'); }

	function update() {
		const now = new Date();
		const h = pad(now.getHours());
		const m = pad(now.getMinutes());
		const s = pad(now.getSeconds());
		clockEl.textContent = `${h}:${m}:${s}`;

		// If the color box exists, map seconds into a hue for gentle shifts
		if (box) {
			const hue = Math.round((now.getSeconds() / 60) * 360);
			const bg = `hsl(${hue} 75% 60%)`;
			box.style.backgroundColor = bg;
		}
	}

	update();
	setInterval(update, 1000);

	// Handle navbar link clicks and set active state based on current page
	const navLinks = document.querySelectorAll('.nav-link');
	
	function setActiveLink() {
		const currentPage = window.location.pathname.split('/').pop() || 'index.html';
		navLinks.forEach(link => {
			const href = link.getAttribute('href');
			if (href.includes(currentPage)) {
				link.classList.add('active');
			} else if (currentPage === '' && href === 'index.html') {
				link.classList.add('active');
			} else {
				link.classList.remove('active');
			}
		});
	}
	
	// Set active link on page load
	setActiveLink();
	
	navLinks.forEach(link => {
		link.addEventListener('click', (e) => {
			// Remove active class from all links
			navLinks.forEach(l => l.classList.remove('active'));
			// Add active class to clicked link
			link.classList.add('active');
		});
	});

	// Interactive button functionality
	const languagesBtn = document.getElementById('languages');
	const languagesMenu = document.getElementById('languages-menu');
	const languageItems = document.querySelectorAll('.language-item');
	
	if (languagesBtn && languagesMenu) {
		// Toggle menu on button click and position it under the button
		languagesBtn.addEventListener('click', (e) => {
			e.preventDefault();
			const aboutEl = document.getElementById('about');
			// Compute position relative to the positioned ancestor (#about)
			if (aboutEl) {
				const btnRect = languagesBtn.getBoundingClientRect();
				const aboutRect = aboutEl.getBoundingClientRect();
				const left = btnRect.left - aboutRect.left + aboutEl.scrollLeft;
				const top = btnRect.bottom - aboutRect.top + aboutEl.scrollTop;
				languagesMenu.style.left = `${left}px`;
				languagesMenu.style.top = `${top}px`;
			}
			languagesMenu.classList.toggle('active');
			const isActive = languagesMenu.classList.contains('active');
			languagesMenu.setAttribute('aria-hidden', String(!isActive));
			if (isActive) {
				const first = languagesMenu.querySelector('.language-item');
				if (first) first.focus();
			}
		});
		
		// Handle language item clicks
		languageItems.forEach(item => {
			item.addEventListener('click', (e) => {
				e.preventDefault();
				const language = item.getAttribute('data-language');
				console.log('Selected language: ' + language);
				languagesMenu.classList.remove('active');
				// Add your custom functionality here for each language
			});
		});
		
		// Close menu when clicking outside
		document.addEventListener('click', (e) => {
			if (!languagesBtn.contains(e.target) && !languagesMenu.contains(e.target)) {
				languagesMenu.classList.remove('active');
				languagesMenu.setAttribute('aria-hidden', 'true');
			}
		});

		// Close on Escape key
		document.addEventListener('keydown', (e) => {
			if (e.key === 'Escape') {
				languagesMenu.classList.remove('active');
				languagesMenu.setAttribute('aria-hidden', 'true');
			}
		});
	}

	// Position buttons absolutely (fixed positions set in CSS)
	const buttonIds = ['languages', 'heritage', 'relationship'];
	const aboutContainer = document.getElementById('about');

	if (aboutContainer) {
		buttonIds.forEach(id => {
			const el = document.getElementById(id);
			if (el) {
				el.style.position = 'absolute';
			}
		});
	}
});
